<template> 
  <div class="chatbot">
    <header>
      <span class="material-symbols-outlined">smart_toy</span>
      <h2>Chatbot</h2>
      <p>Online</p>
      <span class="close-btn material-symbols-outlined">close</span>
    </header>
    <ul class="chatbox" ref="chatbox">
      <li class="chat incoming">
        <span class="material-symbols-outlined">smart_toy</span>
        <p>Olá 👋<br>Como posso te ajudar hoje?</p>
      </li>
    </ul>
    <div class="chat-input">
      <textarea ref="chatInput" placeholder="Digite uma mensagem..." spellcheck="false" required></textarea>
      <span id="send-btn" class="material-symbols-rounded" @click="handleChat">send</span>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue';

export default {
  setup() {
    const chatbox = ref(null);
    const chatInput = ref(null);

    const handleChat = () => {
      const userMessage = chatInput.value.value.trim(); // Obtém a mensagem do usuário do textarea
      if (!userMessage) return;

      // Adicione aqui a lógica para enviar a mensagem ao chatbot ou ao servidor

      // Limpa o textarea após enviar a mensagem
      chatInput.value.value = '';

      // Adiciona a mensagem enviada ao chatbox (opcional)
      const outgoingChatLi = createChatLi(userMessage, "outgoing");
      chatbox.value.appendChild(outgoingChatLi);
      chatbox.value.scrollTo(0, chatbox.value.scrollHeight);

      setTimeout(() => {
        // Adiciona a mensagem "Digitando..." ao chatbox enquanto aguarda a resposta (opcional)
        const incomingChatLi = createChatLi("Digitando...", "incoming");
        chatbox.value.appendChild(incomingChatLi);
        chatbox.value.scrollTo(0, chatbox.value.scrollHeight);
        // Aqui você pode chamar a função para gerar a resposta do chatbot
      }, 600);
    };

    const createChatLi = (message, className) => {
      const chatLi = document.createElement("li");
      chatLi.classList.add("chat", className);
      let chatContent = className === "outgoing" ? `<p></p>` : `<span class="material-symbols-outlined">smart_toy</span><p></p>`;
      chatLi.innerHTML = chatContent;
      chatLi.querySelector("p").textContent = message;
      return chatLi;
    };

    return {
      chatbox,
      chatInput,
      handleChat
    };
  }
};
</script>


