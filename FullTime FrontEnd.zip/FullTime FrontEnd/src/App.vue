<script setup>
import {ref} from 'vue'

let num = ref(0)
</script>

<template> 
    <div class="chatbot"> 
      <div class="top-part">  
        <div class ="agent-details">  
          <img src="https://cdn-icons-png.flaticon.com/512/3662/3662817.png"  alt="">
          <div class="agent-text">
          <h3 id="nickname">SAC Inteligente</h3>
          <p> ChatBot <span>(Online)</span></p>
        </div>
      </div>
    </div>
      <div class="chart-section">
        <div class="left-part">
          <div class="agent-chart">
            <img src="https://cdn-icons-png.flaticon.com/512/3662/3662817.png" alt="">
              <p>Olá, qual seria a dúvida?</p>
          </div>
        </div>
          <div class="right-part">  
            <p>Olá</p>
          </div>
      </div>  
          <div class="chart-section">
            <div class="left-part">
              <div class="agent-chart">
                <img src="https://cdn-icons-png.flaticon.com/512/3662/3662817.png" alt="">
                  <p>Qual sua dúvida para que eu possa lhe fornecer o suporte necessário? </p>
              </div>
            </div>
            <div class="right-part">  
              <p>...</p>
            </div>
          </div>  
          <div class="bottom-section">
            <textarea placeholder="Digite a mensagem..." required></textarea>
            <span id="send-btn" class="material-symbols-outlined">send</span>
          </div>
  </div>
</template>

